/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pat_terminate.h
 *
 * Code generation for function 'pat_terminate'
 *
 */

#ifndef PAT_TERMINATE_H
#define PAT_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void pat_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (pat_terminate.h) */

/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pat_terminate.c
 *
 * Code generation for function 'pat_terminate'
 *
 */

/* Include files */
#include "pat_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void pat_terminate(void)
{
}

/* End of code generation (pat_terminate.c) */

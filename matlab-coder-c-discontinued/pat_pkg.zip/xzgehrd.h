/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * xzgehrd.h
 *
 * Code generation for function 'xzgehrd'
 *
 */

#ifndef XZGEHRD_H
#define XZGEHRD_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void xzgehrd(double a[4], int ilo, int ihi);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (xzgehrd.h) */

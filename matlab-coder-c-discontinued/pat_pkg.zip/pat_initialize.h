/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pat_initialize.h
 *
 * Code generation for function 'pat_initialize'
 *
 */

#ifndef PAT_INITIALIZE_H
#define PAT_INITIALIZE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void pat_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (pat_initialize.h) */

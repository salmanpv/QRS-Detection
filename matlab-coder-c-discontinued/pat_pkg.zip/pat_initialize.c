/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pat_initialize.c
 *
 * Code generation for function 'pat_initialize'
 *
 */

/* Include files */
#include "pat_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void pat_initialize(void)
{
}

/* End of code generation (pat_initialize.c) */

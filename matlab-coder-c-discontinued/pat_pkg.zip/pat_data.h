/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pat_data.h
 *
 * Code generation for function 'pat_data'
 *
 */

#ifndef PAT_DATA_H
#define PAT_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/* End of code generation (pat_data.h) */
